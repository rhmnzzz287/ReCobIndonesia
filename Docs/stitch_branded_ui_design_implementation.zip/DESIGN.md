---
name: ReCob.id
colors:
  surface: '#f0fdf3'
  surface-dim: '#d0ddd4'
  surface-bright: '#f0fdf3'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eaf7ed'
  surface-container: '#e4f1e7'
  surface-container-high: '#dfebe2'
  surface-container-highest: '#d9e6dc'
  on-surface: '#131e18'
  on-surface-variant: '#3f4940'
  inverse-surface: '#28332d'
  inverse-on-surface: '#e7f4ea'
  outline: '#6f7a6f'
  outline-variant: '#bec9bd'
  surface-tint: '#086d3a'
  primary: '#00532a'
  on-primary: '#ffffff'
  primary-container: '#0b6e3b'
  on-primary-container: '#95edad'
  inverse-primary: '#82d99b'
  secondary: '#3d6a00'
  on-secondary: '#ffffff'
  secondary-container: '#aef364'
  on-secondary-container: '#3f6f00'
  tertiary: '#735c00'
  on-tertiary: '#ffffff'
  tertiary-container: '#cfa604'
  on-tertiary-container: '#4e3d00'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#9df6b5'
  primary-fixed-dim: '#82d99b'
  on-primary-fixed: '#00210d'
  on-primary-fixed-variant: '#00522a'
  secondary-fixed: '#b1f667'
  secondary-fixed-dim: '#96d94e'
  on-secondary-fixed: '#0f2000'
  on-secondary-fixed-variant: '#2c5000'
  tertiary-fixed: '#ffe088'
  tertiary-fixed-dim: '#edc22e'
  on-tertiary-fixed: '#241a00'
  on-tertiary-fixed-variant: '#574500'
  background: '#f0fdf3'
  on-background: '#131e18'
  surface-variant: '#d9e6dc'
typography:
  display-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 3.5rem
    fontWeight: '800'
    lineHeight: '1.05'
    letterSpacing: -0.03em
  h1:
    fontFamily: Plus Jakarta Sans
    fontSize: 2.5rem
    fontWeight: '800'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  h2:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.875rem
    fontWeight: '700'
    lineHeight: '1.15'
    letterSpacing: -0.01em
  h3:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.25rem
    fontWeight: '600'
    lineHeight: '1.3'
  body-lg:
    fontFamily: Poppins
    fontSize: 1.125rem
    fontWeight: '400'
    lineHeight: '1.65'
  body-md:
    fontFamily: Poppins
    fontSize: 1rem
    fontWeight: '400'
    lineHeight: '1.6'
  body-sm:
    fontFamily: Poppins
    fontSize: 0.875rem
    fontWeight: '400'
    lineHeight: '1.55'
  label-md:
    fontFamily: Poppins
    fontSize: 0.8125rem
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: 0.08em
  caption:
    fontFamily: Poppins
    fontSize: 0.75rem
    fontWeight: '500'
    lineHeight: '1.45'
  metric-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 3.25rem
    fontWeight: '800'
    lineHeight: '1'
    letterSpacing: -0.03em
  metric-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 2rem
    fontWeight: '700'
    lineHeight: '1.05'
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  margin: 1rem
  space-xs: 0.5rem
  space-sm: 0.75rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

